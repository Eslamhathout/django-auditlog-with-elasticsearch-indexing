django-auditlog-with-elasticsearch-indexing
===========================================

It's the same package for django-auditlog, plus adding the functionality of indexing the logs to Elasticsearch.

